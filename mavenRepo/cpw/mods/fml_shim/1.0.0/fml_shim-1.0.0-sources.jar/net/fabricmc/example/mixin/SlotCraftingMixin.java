package net.fabricmc.example.mixin;

import cpw.mods.fml.common.gameevent.PlayerEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent.ItemCraftedEvent;
import net.minecraft.class_1025;
import net.minecraft.class_1071;
import net.minecraft.class_849;
import net.minecraft.class_988;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1025.class)
public class SlotCraftingMixin {
    @Shadow
    @Final
    private class_849 craftMatrix;

    //ItemCraftedEvent
    @Inject(method = "onPickupFromSlot", at = @At("HEAD"))
    private void forge$onPickupFromSlot(class_988 player, class_1071 stack, CallbackInfo ci) {
        var event = new PlayerEvent.ItemCraftedEvent(player, stack, this.craftMatrix);
        PlayerEvent.ItemCraftedEvent.EVENT.invoker().accept(event);
    }
}
