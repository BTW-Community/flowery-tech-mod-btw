package net.fabricmc.example.mixin;


import com.llamalad7.mixinextras.sugar.Local;
import cpw.mods.fml.common.gameevent.PlayerEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
import net.minecraft.class_743;
import net.minecraft.class_798;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_743.class)
public class ServerConfigurationManagerMixin {
    @Inject(method = "respawnPlayer", at = @At("TAIL"))
    private void forge$respawnPlayer(class_798 oldPlayer, int iDefaultDimension, boolean playerLeavingTheEnd, CallbackInfoReturnable<class_798> cir, @Local(ordinal = 1) class_798 newPlayer) {
        var event = new PlayerEvent.PlayerRespawnEvent(newPlayer);
        PlayerEvent.PlayerRespawnEvent.EVENT.invoker().onPlayerRespawn(event);
    }

    @Inject(method = "playerLoggedOut", at = @At("HEAD"))
    private void forge$onPlayerLoggedOut(class_798 player, CallbackInfo ci) {
        PlayerEvent.PlayerLoggedOutEvent event = new PlayerEvent.PlayerLoggedOutEvent(player);
        PlayerEvent.PlayerLoggedOutEvent.EVENT.invoker().accept(event);
    }
}
