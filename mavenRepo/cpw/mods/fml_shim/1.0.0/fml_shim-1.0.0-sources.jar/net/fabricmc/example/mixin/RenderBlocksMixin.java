package net.fabricmc.example.mixin;

import cpw.mods.fml.client.registry.RenderingRegistry;
import net.minecraft.class_1158;
import net.minecraft.class_197;
import net.minecraft.class_535;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_535.class)
public abstract class RenderBlocksMixin {
    @Shadow
    public class_1158 blockAccess;

    @Inject(method = "renderBlockByRenderType", at = @At(value = "HEAD", shift = At.Shift.AFTER), cancellable = true)
    private void btb$renderWorldBlock(class_197 block, int i, int j, int k, CallbackInfoReturnable<Boolean> cir) {
        int renderType = block.method_429();
        if (renderType == 1) return;
        if (RenderingRegistry.instance().renderWorldBlock(((class_535)(Object) this), this.blockAccess, i, j, k, block, renderType)) {
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "doesRenderIDRenderItemIn3D", at = @At(value = "RETURN"), cancellable = true)
    private static void btb$renderInventoryBlock(int par0, CallbackInfoReturnable<Boolean> cir) {
        if (RenderingRegistry.instance().renderItemAsFull3DBlock(par0)) {
            cir.setReturnValue(true);
        }
    }
}
