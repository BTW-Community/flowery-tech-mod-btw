package cpw.mods.fml.common.gameevent;

import cpw.mods.fml.common.eventhandler.Event;
import net.legacyfabric.fabric.api.event.EventFactory;
import net.minecraft.class_1071;
import net.minecraft.class_849;
import net.minecraft.class_964;
import net.minecraft.class_988;
import java.util.function.Consumer;

public class PlayerEvent extends Event {
    public final class_988 player;
    private PlayerEvent(class_988 player)
    {
        this.player = player;
    }

    public static class ItemPickupEvent extends PlayerEvent {
        public final class_964 pickedUp;
        public ItemPickupEvent(class_988 player, class_964 pickedUp)
        {
            super(player);
            this.pickedUp = pickedUp;
        }
    }

    public static class ItemCraftedEvent extends PlayerEvent {
        public final class_1071 crafting;
        public final class_849 craftMatrix;
        public ItemCraftedEvent(class_988 player, class_1071 crafting, class_849 craftMatrix)
        {
            super(player);
            this.crafting = crafting;
            this.craftMatrix = craftMatrix;
        }
        public static final net.legacyfabric.fabric.api.event.Event<Consumer<ItemCraftedEvent>> EVENT = EventFactory.createArrayBacked(Consumer.class, (listeners) -> (player) -> {
            for (Consumer<ItemCraftedEvent> listener : listeners) {
                listener.accept(player);
            }
        });
    }

    public static class PlayerLoggedInEvent extends PlayerEvent {
        public PlayerLoggedInEvent(class_988 player)
        {
            super(player);
        }
    }

    public static class PlayerLoggedOutEvent extends PlayerEvent {
        public static final net.legacyfabric.fabric.api.event.Event<Consumer<PlayerLoggedOutEvent>> EVENT = EventFactory.createArrayBacked(Consumer.class, (listeners) -> (player) -> {
            for (Consumer<PlayerLoggedOutEvent> listener : listeners) {
                listener.accept(player);
            }
        });
        public PlayerLoggedOutEvent(class_988 player)
        {
            super(player);
        }
    }

    public static class PlayerRespawnEvent extends PlayerEvent {
        public PlayerRespawnEvent(class_988 player)
        {
            super(player);
        }
        public static net.legacyfabric.fabric.api.event.Event<PlayerRespawnEventCallback> EVENT = EventFactory.createArrayBacked(PlayerRespawnEventCallback.class, (callbacks) -> (event) -> {
            for (PlayerRespawnEventCallback eventCallback : callbacks) {
                eventCallback.onPlayerRespawn(event);
            }
        });
        public interface PlayerRespawnEventCallback {
            public void onPlayerRespawn(PlayerRespawnEvent event);
        }
    }

    public static class PlayerChangedDimensionEvent extends PlayerEvent {
        public final int fromDim;
        public final int toDim;
        public PlayerChangedDimensionEvent(class_988 player, int fromDim, int toDim)
        {
            super(player);
            this.fromDim = fromDim;
            this.toDim = toDim;
        }
    }
}