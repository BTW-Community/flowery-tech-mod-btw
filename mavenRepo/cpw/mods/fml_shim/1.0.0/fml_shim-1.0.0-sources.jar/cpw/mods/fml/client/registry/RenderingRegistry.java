package cpw.mods.fml.client.registry;

import com.google.common.collect.Maps;
import net.minecraft.class_1158;
import net.minecraft.class_197;
import net.minecraft.class_535;
import net.minecraft.class_550;
import net.minecraft.class_551;
import net.minecraft.class_864;
import net.minecraft.src.*;

import java.util.Map;

public class RenderingRegistry {
    private static final RenderingRegistry INSTANCE = new RenderingRegistry();
    private int nextRenderId = 45;
    public Map<Integer, ISimpleBlockRenderingHandler> blockRenderers = Maps.newHashMap();

    public static void registerEntityRenderingHandler(Class<? extends class_864> entityClass, class_551 renderer) {
        class_550.addEntityRenderer(entityClass, renderer);
//        instance().entityRenderers.add(new RenderingRegistry.EntityRendererInfo(entityClass, renderer));
    }

    public static void registerBlockHandler(ISimpleBlockRenderingHandler handler) {
        instance().blockRenderers.put(handler.getRenderId(), handler);
    }

    public static void registerBlockHandler(int renderId, ISimpleBlockRenderingHandler handler) {
        instance().blockRenderers.put(renderId, handler);
    }

    public static int getNextAvailableRenderId() {
        return instance().nextRenderId++;
    }

    public static RenderingRegistry instance() {
        return INSTANCE;
    }

    public boolean renderWorldBlock(class_535 renderer, class_1158 world, int x, int y, int z, class_197 block, int modelId) {
        if (!this.blockRenderers.containsKey(modelId)) {
            return false;
        } else {
            ISimpleBlockRenderingHandler bri = this.blockRenderers.get(modelId);
            return bri.renderWorldBlock(world, x, y, z, block, modelId, renderer);
        }
    }

    public boolean renderInventoryBlock(class_535 renderer, class_197 block, int metadata, int modelID) {
        if (this.blockRenderers.containsKey(modelID)) {
            ISimpleBlockRenderingHandler bri = this.blockRenderers.get(modelID);
            bri.renderInventoryBlock(block, metadata, modelID, renderer);
            return true;
        }
        return false;
    }

    public boolean renderItemAsFull3DBlock(int modelId) {
        ISimpleBlockRenderingHandler bri = blockRenderers.get(modelId);
        return bri != null && bri.shouldRender3DInInventory(modelId);
    }

    public void loadEntityRenderers() {
        //NOOP
    }

    public void loadEntityRenderers(Map<Class<? extends class_864>, class_551> rendererMap) {
        //NOOP
    }
}
