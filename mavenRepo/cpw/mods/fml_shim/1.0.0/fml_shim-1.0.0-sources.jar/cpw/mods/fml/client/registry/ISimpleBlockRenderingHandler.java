package cpw.mods.fml.client.registry;

import net.minecraft.class_1158;
import net.minecraft.class_197;
import net.minecraft.class_535;

public interface ISimpleBlockRenderingHandler {
    void renderInventoryBlock(class_197 block, int i, int j, class_535 renderBlocks);

    boolean renderWorldBlock(class_1158 iBlockAccess, int i, int j, int k, class_197 block, int l, class_535 renderBlocks);

    boolean shouldRender3DInInventory(int modelId);

    int getRenderId();
}
